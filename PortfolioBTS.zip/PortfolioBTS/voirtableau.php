        <link href="css/styles.css" rel="stylesheet" />
<embed src='pdf/YAGOUBI Tableau.pdf' width="100%" height="90%" type='application/pdf' />
<p>
<center><a class="btn btn-primary js-scroll-trigger" href="index.html">Retour</a></center>